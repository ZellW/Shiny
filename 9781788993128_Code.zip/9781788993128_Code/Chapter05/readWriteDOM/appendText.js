
<script type="text/javascript">

function buttonClick(){
  
  var elem = document.getElementById('selection');
  
  elem.innerHTML = elem.innerHTML + ", " + document.getElementById('year').value;
}  

</script>